'''
Author: Hugh MacMillan
What: A script for inputting and adjusting Cheetah's baseball lineups, Spring 2019
Created: 4/15/2019
Updated: 5/1/2019
'''

print("CHEETAHS BASEBALL")
print("")
print("")

# A list that acts as a 'table' of rows
lstTable = []
keys = ["Game number","Innings","Player name","Batting position",
         "inning 1", "inning 2", "inning 3", "inning 4", "inning 5"]
#print(keys)

objFile = open("Games.txt", "r")
lines = objFile.readlines()
print("*****--*****--*****")
first_row_flag = 1
#each line in lines has the raw rows
for line in lines:
#        print(line)
# separate out the entries in line
    dictionary_row = {}
    lst_line_data = line.split(",")
#    print(lst_line_data)
    for k in range(len(lst_line_data)):
#        print(lst_line_data[k])
        lst_line_data[k] = lst_line_data[k].replace("\'", "").replace("[", "").replace("]", "").replace("\n",                                                                                                    "").strip()
#        print(lst_line_data[k])
#        print("***"+keys[k]+"***")
#        print(dictionary_row)
        dictionary_row.update({keys[k]:lst_line_data[k]})
#    print(dictionary_row)
    lstTable.append(dictionary_row)
#for row in lstTable:
#    print(row)
objFile.close()
print("")
print("*****--*****--*****")

while (True):
    option = int(input("Enter 1 to view, 2 to input game data, 3 to pickle it, or 0 to quit:"))
    if option == 1:
        objFile = open("Games.txt", "r")
        lines = objFile.readlines()[1:]
        objFile.close()
        print("*****--*****--*****")
        lstTable = []
        for line in lines:
#            print(line)
            dictionary_row = {}
            lst_line_data = line.split(",")
            for k in range(len(lst_line_data)):
                lst_line_data[k] = \
                    lst_line_data[k].replace("\'", "").replace("[", "").replace("]", "").replace("\n","").strip()
                dictionary_row.update({keys[k]: lst_line_data[k]})
            lstTable.append(dictionary_row)
#            print(dictionary_row)
#            print(", ".join(lst_line_data))
        print("")
        print("*****--*****--*****")
        print("-------")
#        print(lstTable[12])
#        print(len(lstTable))
#        print(lstTable)
        for row_to_print in lstTable:
            innings_played = row_to_print[keys[1]]
            if (int(innings_played) < 4 ):
 #               print(row_to_print)
                print(row_to_print[keys[0]] + ' ' + row_to_print[keys[2]] + '--' +
                      row_to_print[keys[3]] + '---' + row_to_print[keys[4]] + ' ' +
                      row_to_print[keys[5]] + ' ' + row_to_print[keys[6]])
            elif (int(innings_played) == 4):
                print(row_to_print[keys[0]] + ' ' + row_to_print[keys[2]] + '--' +
                      row_to_print[keys[3]] + '---' + row_to_print[keys[4]] + ' ' +
                      row_to_print[keys[5]] + ' ' + row_to_print[keys[6]]+ ' ' + row_to_print[keys[7]])
            elif (int(innings_played) == 5):
                print(row_to_print[keys[0]] + ' ' + row_to_print[keys[2]] + '--' +
                      row_to_print[keys[3]] + '---' + row_to_print[keys[4]] + ' ' +
                      row_to_print[keys[5]] + ' ' + row_to_print[keys[6]]+' '+ row_to_print[keys[7]]+' ' + row_to_print[keys[8]])
        usr_input_viewing = int(input("Would you like to view by player (1), position (2), game (3) or neither (0)?"))
        if usr_input_viewing == 1:
            player_to_view = input("Enter first name of player to view:")
            for row_hit in lstTable:
#                print(player_to_view)
                if (row_hit[keys[2]] == player_to_view):
                    print("Game ", row_hit[keys[0]],", ",
                          player_to_view, "played:", row_hit[keys[4]], ",",
                          row_hit[keys[5]], ", and ", row_hit[keys[6]])
                continue
#            hits = filter(lambda x: x[keys[2]] == player_to_view, lstTable)
        elif usr_input_viewing == 2:
            continue
        elif usr_input_viewing == 3:
            continue
        elif usr_input_viewing == 0:
            continue
    elif option == 2:
        game_no = int(input("Enter game number: (e.g., 1, 2...): "))
        objFile = open("Games.txt", "a")
        print("")
        innings_played = int(input("Enter innings played: "))
        print("")
        # = print("OK, Cheetahs won? ")

        print("Enter 'Exit' at any time to stop entering player data")
        top_line = 1
        if top_line == 0:
            objFile.write("Player name"+
                          ","+"Game number"+
                          ","+"Inning"+
                          ","+"Batting position"+
                          ","+"fielding position"+"\n")

        lst_innings_played = []
        lst_players_present = []
        lst_batting_position = []
        fielding_position = "x"

        while(True):
            if (fielding_position == "exit"): break
            player_name = input("Enter player's first name: ")
            if (player_name.lower() == "exit"): break
            lst_players_present.append(player_name)
            print(type(player_name))
            batting_position = input("Enter player's ba1tting position: ")
            if (batting_position == "exit"): break
            lst_players_present.append(player_name)
    #        print(type(batting_position))
            inning_counter = 1
            lst_fielding_position = []
            while(inning_counter <= innings_played):
                fielding_position = input("Enter player's fielding position, inning {}: ".format(inning_counter))
    #            print(type(fielding_position))
                lst_fielding_position.append(fielding_position)
                if(fielding_position == "exit"): break
                else: inning_counter = inning_counter + 1
            print(lst_fielding_position)
    #        lst_fielding_position[0] = list_fielding_position[0]
            objFile.write(str(game_no) + "," + str(innings_played) + "," +player_name + "," + batting_position + "," + str(
                lst_fielding_position) + "\n")
        objFile.close()
        continue
    elif option == 3: # this is a way of writing a diction, and reading it back into a list object
        import pickle
        f_pickle = open('hitting_batting.pkl', 'wb')
        pickle.dump(lstTable, f_pickle, -1)
        f_pickle.close()
        f_pickle = open('hitting_batting.pkl', 'rb')
        mydict = pickle.load(f_pickle)
        f_pickle.close()
        print("this is the result is an list of dictionaries:", mydict)
        print("the list has ",len(mydict), "dictionaries")
#        print(type(mydict))
#        for i in range(len(mydict)):
#            print(mydict[i])
#           print(type(mydict[i]))
        continue
    elif option == 0: break
    elif option not in [0,1,2,3]:
        option = int(input("Please enter 1 to view, 2 to input game data, 3 to pickle it, or 0 to quit:"))
        if option not in [0,2,3,1]:
            raise Exception('You entered something other than 0, 1, 2 or 3. You entered',format(option))
