'''
Author: Hugh MacMillan
What: A script for inputting and adjusting Cheetah's baseball lineups, Spring 2019
Created: 4/15/2019
Updated: 4/28/2019
'''
'''
Create a new script that manages a "ToDo list." 
This time the ToDo file will contain different columns of data (Task, Priority) which are stored in a Python Dictionary. 
Each Dictionary will represent one row of data and these rows of data are added to a Python List to create a table of data.

When the program starts, load each row of data from the ToDo.txt text file into a Python dictionary. 
The data will be stored like a row in a table.
Use a for loop to read a single line of text from the file and then place the data into a new dictionary object.
After you get the data in a Python dictionary, add the new dictionary “row” into a Python list object (now the data 
will be managed as a table).Display the contents of the List to the user.

Allow the user to Add or Remove tasks from the list using numbered choices. 
Something like this would work: 
    Menu of Options
    1) Show current data
    2) Add a new item.
    3) Remove an existing item.
    4) Save Data to File
    5) Exit Program

Save the data from the table into the Todo.txt file when the program exits.
'''

# -- Processing --#
# Step 1
# When the program starts, load the any data you have
# in a text file called ToDo.txt into a python Dictionary.

# Step 2
# Display a menu of choices to the user

# Step 3
# Display all todo items to user

# Step 4
# Add a new item to the list/Table

# Step 5
# Remove a new item to the list/Table

# Step 6
# Save tasks to the ToDo.txt file

# Step 7
# Exit program
# -------------------------------
print("")
print("")
# -- Data --#
# declare variables and constants
# An object that represents a file
objFile = open("ToDo.txt", "r")
# A row of text data from the file
strData = ""
# A row of data separated into elements of a dictionary {Task,Priority}
dicRow = {}
# A dictionary that acts as a 'table' of rows
lstTable = []
# A menu of user options
# Capture the user option selection
strChoice = ""

# Step 1 - Load data from a file
# When the program starts, load each "row" of data
# in "ToDo.txt" into a python Dictionary.
# Add the each dictionary "row" to a python list "table"
lines = objFile.readlines()
print("Greetings!")
print("Current items on your to do list:")
print("")
print("*****--*****--*****")
print("")
print("Task" + ', ' + 'Priority')
print("")
for line in lines:
    lst_line_data = line.split(",")
#            print(lst_line_data[0])
    dicRow = {"Task": lst_line_data[0], "Priority": lst_line_data[1]}
#    print("")
#    print("---*****---")
    str_to_fix = dicRow['Priority']
#    print(type(dicRow['Priority']))
#    print(dicRow)
#    str_fixed = str_to_fix.replace('\n','')
    dicRow['Priority'] = str_to_fix.replace('\n','')
#    print(dicRow)
#    print(dicRow['Priority'])
#    print(type(lst_line_data[1]))
#    print(lst_line_data[1])
    print(dicRow['Task']+', '+dicRow['Priority'])
    lstTable.append(dicRow)
print("")
print("*****--*****--*****")
print("")
#print(lstTable)
objFile.close()


#    difRow{"Priority"} = lst_line)_dat[1]
# Step 2 - Display a menu of choices to the user

while (True):
    print("""
    Your menu of Options
    1) Show current data
    2) Add a new item.
    3) Remove an existing item.
    4) Save Data to File
    5) Exit Program
    """)
    strChoice = str(input("Which option would you like to perform? [1 to 4] - "))
    print("")  # adding a new line
    # Step 3 -Show the current items in the table
    if (strChoice.strip() == '1'):
        objFile = open("ToDo.txt", "r")
        lines = objFile.readlines()
        print("")
        print("Things to do:")
        print("*****--*****--*****")
        print("")
        for row in lstTable:
            print(row['Task'] + ', ' + row['Priority'])
        print("*****--*****--*****")
        print("")
        objFile.close()
        continue
    # If strChoice = 2, add a new item to the list/Table
    elif (strChoice.strip() == '2'):
#        print(strChoice)
#        print(lstTable)
        str_new_task = str(input("Enter the new task to do: "))
        str_new_task_priority = str(input("Enter the new task priority (low, medium or high): "))
        dicRow = {"Task": str_new_task, "Priority": str_new_task_priority}
        lstTable.append(dicRow)
        print(str_new_task, " was added to your to do list! Enter 4 to save.")
#        print(lstTable)
        continue
    # if sgtrChoice = 3, remove a new item to the list/Table
    elif (strChoice == '3'):
#        print(strChoice)
#        print(lstTable)
        str_done_task = str(input("What task do you wish to drop? "))
#        print(len(lstTable))
        for i in range(len(lstTable)):
  #          print(lstTable[i])
 #           print(lstTable[i]['Task'])
#            print(str_done_task)
            if lstTable[i]['Task'].lower() == str_done_task.lower():
                del lstTable[i]
                print(str_done_task + " was dropped from your to do list, but you still must save it.")
                break
#        print("*")
#        print(len(lstTable))
        continue
    # Step 6 - Save tasks to the ToDo.txt file
    elif (strChoice == '4'):
        objFile = open("ToDo.txt","w")
        print("Your To Do list was saved to ToDo.txt.")
#        print(strChoice)
#        print(lstTable)
#        print(len(lstTable))
#        print("---")
        for i in range(len(lstTable)):
#            print(type(lstTable[i]))
#            print(lstTable[i]['Task'])
#            print(type(lstTable[i]['Task']))
#            print(lstTable[i]['Priority'])
#            print(i)
#            print(len(lstTable))
            objFile.write(str(lstTable[i]['Task']) + ',' + str(lstTable[i]['Priority'])+'\n')
        objFile.close()
        continue
    elif (strChoice == '5'):break
          # and Exit the program



'''
print("This programs allows you to view (option 1) or input (option 2) Cheetahs data,")
print("namely batting order, and the defensive positions played in innings played.")
print("")
print("")
option = int(input("Enter 1 to view or 2 to input game data:"))

if option == 1:
    print("under construction")


game_no = int(input("Enter game number: (e.g., 1, 2...): "))

#objFile = open("/Users/hughrobertmac/_2019/Cheethas/Game_1.csv", "a")
objFile = open("/Users/hughrobertmac/_2019/_pythonclass/Module05/Assignment_05/todo_list.txt", "w")

print("")
innings_played = int(input("Enter innings played: "))
print("")
# = print("OK, Cheetahs won? ")

print("Enter 'Exit' at any time to quit")

#Creat top line for data written to file

objFile.write("Player name"+
                  ","+"Game number"+
                  ","+"Inning"+
                  ","+"Batting position"+
                  ","+"fielding position"+"\n")

lst_game_no = []
lst_innings_played = []
lst_players_present = []
lst_batting_position = []
fielding_position = "x"

while(True):
    if (fielding_position == "exit"): break
    player_name = input("Enter player's first name: ")
    if (player_name.lower() == "exit"): break
    lst_players_present.append(player_name)
    print(type(player_name))
    batting_position = input("Enter player's batting position: ")
    if (batting_position == "exit"): break
    lst_players_present.append(player_name)
    print(type(batting_position))
    inning_counter = 1
    lst_fielding_position = []
    while(inning_counter <= innings_played):
        fielding_position = input("Enter player's fielding position, inning {}: ".format(inning_counter))
        print(type(fielding_position))
        lst_fielding_position.append(fielding_position)
        if(fielding_position == "exit"): break
        else: inning_counter = inning_counter + 1
    objFile.write(str(game_no) + "," + str(innings_played) + "," +player_name + "," + batting_position + "," + str(
        lst_fielding_position) + "\n")
objFile.close()
'''