'''
Author: Hugh MacMillan
What: A script defining a class and functions for
        managing a To-do list.
Created: 4/15/2019
Updated: 5/2/2019
'''


# -- Processing --#
#Opening
# Load data from ToDo.txt into a python Dictionary.

# Step 2
# Display menu

# Step 3
# Display To-do list

# Step 4
# Add a new item to the list

# Step 5
# Remove a new item from the list

# Step 6
# Save tasks to ToDo.txt

# Step 7
# Exit program
# -------------------------------
print("")
print("")
# -- Data --#
# declare variables and constants
# An object that represents a file
#objFile = open("ToDo.txt", "r")
# A row of text data from the file
strData = ""
# A row of data separated into elements of a dictionary {Task,Priority}
dicRow = {}
# A dictionary that acts as a 'table' of rows
lstTable = []
# A menu of user options
# Capture the user option selection
strChoice = ""


#  -- processing code --
#  Create a Class to hold list of functions

class ThingsToDo(object):
    """ This class contains methods for managing a list of pairs """
    # Define the methods
    #
    # == loading
    #
    @staticmethod #
    def load_items():
        loaded_table = []
        objFile = open("ToDo.txt", "r")
        lines = objFile.readlines()
        print("Greetings!")
        print("Current items on your to do list:")
        print("")
        print("*****--*****--*****")
        print("")
        print("Task" + ', ' + 'Priority')
        print("")
        for line in lines:
            lst_line_data = line.split(",")
            #            print(lst_line_data[0])
            dicRow = {"Task": lst_line_data[0], "Priority": lst_line_data[1]}
            str_to_fix = dicRow['Priority']
            dicRow['Priority'] = str_to_fix.replace('\n', '')
            print(dicRow['Task'] + ', ' + dicRow['Priority'])
            loaded_table.append(dicRow)
        print("")
        print("*****--*****--*****")
        print("")
        objFile.close()
        return loaded_table
    #
    # printing
    #
    #@staticmethod
    def print_items(table_to_print):
        """ This function prints a table of dictionary rows of length 2"""
        objFile = open("ToDo.txt", "r")
        lines = objFile.readlines()
        print("")
        print("Here are your things to do:")
        print("*****--*****--*****")
        print("")
        for row in table_to_print:
            print(row['Task'] + ', ' + row['Priority'])
        print("*****--*****--*****")
        print("")
        objFile.close()
        return
    #
    # add an item
    #
    #@staticmethod
    def add_item(table_addition):
        """ This function adds a length-2 dictonary row to a table of dictionary rows"""
        dicRow = {}
        str_new_task = str(input("Enter the new task to do: "))
        str_new_task_priority = str(input("Enter the new task priority (low, medium or high): "))
        dicRow = {"Task": str_new_task, "Priority": str_new_task_priority}
        table_addition.append(dicRow)
        print(str_new_task, " was added to your to do list! Enter 4 to save.")
        return table_addition
    #
    # drop an item
    #
    #@staticmethod
    def drop_item(table_drop):
        str_done_task = ""
        drop_flag = False
        str_done_task = str(input("What task do you wish to drop? "))
        for i in range(len(table_drop)):
            if table_drop[i]['Task'].lower() == str_done_task.lower():
                del lstTable[i]
                print(str_done_task + " was dropped from your to do list, but you still must save it.")
                drop_flag = True
                break
        if drop_flag == False:
            print("I'm sorry but I dont see that task on the list.")
#           input_drop_issue = input("Enter")
        return table_drop
    @staticmethod
    #
    # saving items
    #
    def save_items(table_to_save):
        objFile = open("ToDo.txt", "w")
        for i in range(len(table_to_save)):
            objFile.write(str(table_to_save[i]['Task']) + ',' + str(table_to_save[i]['Priority']) + '\n')
        objFile.close()
        print("Your To Do list was saved to ToDo.txt.")
        return


# -- presentation (I/0) code --
# Call the method (function)
# Step 1 - Load data from a file
# When the program starts, load each "row" of data
# in "ToDo.txt" into a python table of dictionary rows, lstTable
#

lstTable = ThingsToDo.load_items()

# Then display a menu of choices to the user

while (True):
    print("""
    Your menu of Options
    1) Show current data
    2) Add a new item.
    3) Remove an existing item.
    4) Save Data to File
    5) Exit Program
    """)
    strChoice = str(input("Which option would you like to perform? [1 to 5] - "))
    print("")  # adding a new line
    # Step 3 - Allow for seeing, changing and saving items on a todo list
    #
    #  Print current items in the table if strChoice = 1
    if (strChoice.strip() == '1'):
        ThingsToDo.print_items(lstTable)
        continue
    # If strChoice = 2, prompt user to add a new item
    elif (strChoice.strip() == '2'):
        lstTable = ThingsToDo.add_item(lstTable)
        continue
    # If strChoice = 3, prompt user to drop an item
    elif (strChoice == '3'):
        lstTable = ThingsToDo.drop_item(lstTable)
        continue
    # If strChoice = 4, save tasks to the ToDo.txt file
    elif (strChoice == '4'):
        ThingsToDo.save_items(lstTable)
        continue
    elif (strChoice == '5'):break
          # and Exit the program